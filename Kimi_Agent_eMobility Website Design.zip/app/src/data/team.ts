export const teamMembers = [
  {
    id: '1',
    name: 'Brian Otieno',
    title: 'Founder & CEO',
    bio: 'A mobility entrepreneur with 10+ years in East African logistics and clean tech.',
    image: '/images/about-brian.jpg'
  },
  {
    id: '2',
    name: 'Sarah Nambatya',
    title: 'Head of Operations',
    bio: 'Leads our fleet programs and service network across 5 countries.',
    image: '/images/about-sarah.jpg'
  },
  {
    id: '3',
    name: 'Daniel Kibet',
    title: 'Lead Engineer',
    bio: 'Designs and tests every frame, motor, and battery for African conditions.',
    image: '/images/about-daniel.jpg'
  }
];
