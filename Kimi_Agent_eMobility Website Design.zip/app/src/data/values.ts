export const values = [
  {
    id: '1',
    title: 'Sustainability',
    description: 'Every product is designed to reduce emissions and waste. We recycle batteries and source locally where possible.',
    icon: 'Leaf'
  },
  {
    id: '2',
    title: 'Accessibility',
    description: 'Affordable pricing, flexible payment plans, and a service network that reaches rural and urban riders alike.',
    icon: 'Users'
  },
  {
    id: '3',
    title: 'Innovation',
    description: 'We continuously improve our motors, batteries, and software based on real rider feedback from East African roads.',
    icon: 'Zap'
  },
  {
    id: '4',
    title: 'Community',
    description: 'We partner with local riders, delivery associations, and cooperatives to grow the eMobility ecosystem together.',
    icon: 'Heart'
  }
];
