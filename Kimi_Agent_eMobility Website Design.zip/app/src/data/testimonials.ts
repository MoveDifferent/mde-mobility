export const testimonials = [
  {
    id: '1',
    name: 'James Ochieng',
    role: 'Boda boda rider, Nairobi',
    quote: 'I save over KSh 800 a day on fuel. My eBike pays for itself.',
    avatar: '/images/avatar-james.jpg'
  },
  {
    id: '2',
    name: 'Amina Hassan',
    role: 'Fleet Manager, QuickDeliver',
    quote: 'The fleet program cut our delivery costs by half. The support team is always available.',
    avatar: '/images/avatar-amina.jpg'
  },
  {
    id: '3',
    name: 'David Mwangi',
    role: 'Daily commuter, Kampala',
    quote: 'No more traffic stress. I glide past jams and charge at the office.',
    avatar: '/images/avatar-david.jpg'
  }
];
