export const articles = [
  {
    id: '1',
    title: 'Move Different Launches Next-Gen Delivery Pro with 120km Range',
    category: 'Product Updates',
    excerpt: 'Our most advanced delivery bike yet — built for the toughest East African routes with extended range and heavy-duty cargo capacity.',
    date: 'March 15, 2026',
    image: '/images/blog-featured.jpg',
    featured: true
  },
  {
    id: '2',
    title: 'How eBikes Are Transforming Last-Mile Delivery in Nairobi',
    category: 'Industry News',
    excerpt: 'From traffic jams to efficient deliveries — how electric bikes are reshaping logistics in Kenya\'s capital.',
    date: 'March 10, 2026',
    image: '/images/blog-nairobi-delivery.jpg',
    featured: false
  },
  {
    id: '3',
    title: 'James Ochieng: From Fuel Costs to Financial Freedom',
    category: 'Rider Stories',
    excerpt: 'A boda boda rider in Nairobi shares how switching to electric cut his daily costs and changed his life.',
    date: 'February 28, 2026',
    image: '/images/blog-rider-james.jpg',
    featured: false
  },
  {
    id: '4',
    title: 'Uganda Government Announces eMobility Incentives for 2026',
    category: 'East Africa eMobility',
    excerpt: 'New tax breaks and import incentives signal a major shift towards clean transport in Uganda.',
    date: 'February 20, 2026',
    image: '/images/blog-uganda-gov.jpg',
    featured: false
  },
  {
    id: '5',
    title: 'Battery Care 101: Maximizing Your eBike\'s Lifespan',
    category: 'Product Updates',
    excerpt: 'Simple tips to extend your battery life and get the most kilometers from every charge.',
    date: 'February 10, 2026',
    image: '/images/blog-battery-care.jpg',
    featured: false
  },
  {
    id: '6',
    title: 'Move Different Expands Service Network to Rwanda',
    category: 'Industry News',
    excerpt: 'Our newest service center in Kigali opens doors, bringing local support to Rwandan riders.',
    date: 'January 28, 2026',
    image: '/images/blog-rwanda-service.jpg',
    featured: false
  }
];

export const categories = ['All', 'Industry News', 'Product Updates', 'Rider Stories', 'East Africa eMobility'];
