export const timelineMilestones = [
  { year: '2019', event: 'Move Different Group founded in Nairobi, Kenya.' },
  { year: '2022', event: 'eMobility division launched with first commuter eBike prototype.' },
  { year: '2023', event: 'First fleet partnership signed with QuickDeliver Kenya.' },
  { year: '2024', event: 'Regional expansion into Uganda and Tanzania.' },
  { year: '2025', event: '1,000th bike sold. Service centers open in Rwanda and Ethiopia.' },
  { year: '2026', event: 'Move Different eMobility rebrand and next-gen product line launch.' }
];
