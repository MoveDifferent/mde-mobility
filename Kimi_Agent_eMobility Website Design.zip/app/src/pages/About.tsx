import { motion } from 'framer-motion';
import { Quote } from 'lucide-react';
import { teamMembers } from '@/data/team';
import { timelineMilestones } from '@/data/timeline';
import { values } from '@/data/values';
import ScrollReveal from '@/components/ScrollReveal';
import SectionHeader from '@/components/SectionHeader';
import ValueCard from '@/components/ValueCard';
import { pageTransitionVariant, staggerContainerVariant, staggerItemVariant } from '@/animations/variants';

export default function About() {
  return (
    <motion.div
      variants={pageTransitionVariant}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      {/* HERO */}
      <section className="pt-32 pb-16 lg:pb-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div>
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="text-xs font-semibold uppercase tracking-[0.15em] text-deep-green mb-4"
              >
                Our Story
              </motion.p>
              <div className="overflow-hidden">
                <motion.h1
                  initial={{ y: '110%' }}
                  animate={{ y: 0 }}
                  transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
                  className="font-display text-4xl lg:text-5xl xl:text-6xl font-medium text-deep-green leading-[1.08]"
                >
                  Born in East Africa.
                </motion.h1>
              </div>
              <div className="overflow-hidden mb-6">
                <motion.h1
                  initial={{ y: '110%' }}
                  animate={{ y: 0 }}
                  transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1], delay: 0.08 }}
                  className="font-display text-4xl lg:text-5xl xl:text-6xl font-medium text-deep-green leading-[1.08]"
                >
                  Built for the World.
                </motion.h1>
              </div>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="text-text-primary/70 leading-relaxed"
              >
                Move Different eMobility is the electric mobility division of Move Different Group. We believe East Africa's future is electric — and we're building it, one bike at a time. From our headquarters in Nairobi, we're creating sustainable, affordable transportation solutions for the people who need them most.
              </motion.p>
            </div>
            <ScrollReveal variant="scale-settle">
              <img
                src="/images/about-team.jpg"
                alt="Move Different Team"
                className="w-full aspect-video object-cover"
              />
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* MISSION & VISION */}
      <section className="py-20 lg:py-28 bg-light-green">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
            {/* Mission */}
            <ScrollReveal>
              <div className="bg-white rounded-xl p-8 lg:p-10 relative">
                <Quote size={48} className="text-deep-green/10 absolute top-6 left-6" />
                <div className="relative z-10 pt-8">
                  <p className="font-display text-lg lg:text-xl italic text-deep-green leading-relaxed">
                    "To make electric mobility accessible, affordable, and reliable for every East African."
                  </p>
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-text-primary/50 mt-6">
                    — Move Different Mission
                  </p>
                </div>
              </div>
            </ScrollReveal>

            {/* Vision */}
            <ScrollReveal delay={0.15}>
              <div className="bg-white rounded-xl p-8 lg:p-10 relative">
                <Quote size={48} className="text-deep-green/10 absolute top-6 left-6" />
                <div className="relative z-10 pt-8">
                  <p className="font-display text-lg lg:text-xl italic text-deep-green leading-relaxed">
                    "A greener East Africa where clean transport powers economic growth and healthier cities."
                  </p>
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-text-primary/50 mt-6">
                    — Move Different Vision
                  </p>
                </div>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* TEAM */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <SectionHeader
              title="The People Behind the Movement"
              align="center"
              className="mb-12"
            />
          </ScrollReveal>
          <motion.div
            variants={staggerContainerVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.15 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            {teamMembers.map((member) => (
              <motion.div key={member.id} variants={staggerItemVariant} className="group">
                <div className="aspect-[3/4] overflow-hidden mb-5">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
                    loading="lazy"
                  />
                </div>
                <h3 className="font-body text-lg font-semibold text-deep-green">{member.name}</h3>
                <p className="text-xs font-semibold uppercase tracking-[0.12em] text-text-primary/50 mt-1">
                  {member.title}
                </p>
                <p className="text-text-primary/70 text-sm mt-2 leading-relaxed">{member.bio}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* TIMELINE */}
      <section className="py-20 lg:py-28 bg-surface">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <SectionHeader
              title="Our Journey"
              align="center"
              className="mb-16"
            />
          </ScrollReveal>

          <div className="relative">
            {/* Vertical Line */}
            <div className="absolute left-4 lg:left-1/2 top-0 bottom-0 w-0.5 bg-deep-green/20" />

            <div className="space-y-12">
              {timelineMilestones.map((milestone, i) => (
                <ScrollReveal key={milestone.year} delay={i * 0.08}>
                  <div className={`relative flex items-start gap-6 ${i % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'}`}>
                    {/* Dot */}
                    <div className="absolute left-4 lg:left-1/2 w-3 h-3 bg-electric-green rounded-full -translate-x-1/2 mt-2 z-10" />

                    {/* Content */}
                    <div className={`ml-12 lg:ml-0 lg:w-[45%] ${i % 2 === 0 ? 'lg:pr-12 lg:text-right' : 'lg:pl-12'}`}>
                      <span className="text-electric-green font-display text-2xl font-semibold">
                        {milestone.year}
                      </span>
                      <p className="text-text-primary/70 mt-1 text-sm leading-relaxed">
                        {milestone.event}
                      </p>
                    </div>
                    <div className="hidden lg:block lg:w-[45%]" />
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* VALUES */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <SectionHeader
              title="Our Values"
              align="center"
              className="mb-12"
            />
          </ScrollReveal>
          <motion.div
            variants={staggerContainerVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.15 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10"
          >
            {values.map((v) => (
              <motion.div key={v.id} variants={staggerItemVariant}>
                <ValueCard icon={v.icon} title={v.title} description={v.description} />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
    </motion.div>
  );
}
