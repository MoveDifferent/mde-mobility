import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Battery, Gauge, Zap, Timer } from 'lucide-react';
import { getProductBySlug, getRelatedProducts } from '@/data/products';
import ScrollReveal from '@/components/ScrollReveal';
import SectionHeader from '@/components/SectionHeader';
import ProductCard from '@/components/ProductCard';
import { pageTransitionVariant, staggerContainerVariant, staggerItemVariant } from '@/animations/variants';

const colorSwatches: Record<string, string> = {
  'Matte Black': '#1A1A2E',
  'Forest Green': '#1A7A4A',
  'Sand Grey': '#C4B9AC',
  'White': '#F5F5F5',
};

export default function ProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const product = getProductBySlug(slug || '');
  const relatedProducts = getRelatedProducts(slug || '');

  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedColor, setSelectedColor] = useState(0);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-3xl text-deep-green mb-4">Product Not Found</h1>
          <Link to="/products" className="text-electric-green hover:underline">
            Browse all products
          </Link>
        </div>
      </div>
    );
  }

  const images = [product.image, product.image, product.image, product.image];

  const specIcons = [
    { icon: <Battery size={20} />, label: product.fullSpecs?.Battery || product.specs },
    { icon: <Zap size={20} />, label: product.fullSpecs?.Motor || 'Motor info' },
    { icon: <Gauge size={20} />, label: product.fullSpecs?.Range || 'Range info' },
    { icon: <Timer size={20} />, label: product.fullSpecs?.['Top Speed'] || 'Speed info' },
  ];

  return (
    <motion.div
      variants={pageTransitionVariant}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      {/* BREADCRUMB */}
      <div className="pt-28 pb-4 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="text-xs text-text-primary/60">
            <Link to="/products" className="hover:text-deep-green">Products</Link>
            <span className="mx-2">/</span>
            <span className="capitalize">{product.category}</span>
            <span className="mx-2">/</span>
            <span className="text-deep-green font-medium">{product.name}</span>
          </nav>
        </div>
      </div>

      {/* PRODUCT HERO */}
      <section className="pb-16 lg:pb-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-[55%_45%] gap-10 lg:gap-12">
            {/* Gallery */}
            <div>
              <div className="aspect-[4/3] overflow-hidden rounded-lg bg-surface">
                <motion.img
                  key={selectedImage}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.25 }}
                  src={images[selectedImage]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex gap-2 mt-3">
                {images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(i)}
                    className={`w-[72px] h-[72px] overflow-hidden rounded border-2 transition-colors ${
                      selectedImage === i ? 'border-electric-green' : 'border-transparent hover:border-deep-green/30'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Info */}
            <div className="lg:pl-4">
              <h1 className="font-display text-3xl lg:text-5xl font-medium text-deep-green">
                {product.name}
              </h1>
              <p className="text-lg text-text-primary/70 italic mt-2">{product.tagline}</p>
              <p className="text-2xl lg:text-3xl font-bold text-electric-green mt-6">
                {product.price}
              </p>

              {/* Color Options */}
              {product.colors && product.colors.length > 0 && (
                <div className="mt-6">
                  <p className="text-sm font-semibold text-deep-green mb-3">
                    Color: {product.colors[selectedColor]}
                  </p>
                  <div className="flex gap-3">
                    {product.colors.map((color, i) => (
                      <button
                        key={color}
                        onClick={() => setSelectedColor(i)}
                        className={`w-8 h-8 rounded-full border-2 transition-all ${
                          selectedColor === i ? 'border-electric-green scale-110' : 'border-transparent'
                        }`}
                        style={{ backgroundColor: colorSwatches[color] || '#ccc' }}
                        title={color}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Quick Specs */}
              <div className="grid grid-cols-2 gap-4 mt-8">
                {specIcons.map((spec, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <div className="text-deep-green mt-0.5">{spec.icon}</div>
                    <span className="text-sm text-text-primary/80">{spec.label}</span>
                  </div>
                ))}
              </div>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row gap-4 mt-10">
                <button className="flex-1 px-8 py-4 bg-electric-green text-white font-semibold rounded-full hover:bg-deep-green hover:scale-[1.03] transition-all duration-250">
                  Buy Now
                </button>
                <Link
                  to="/fleet"
                  className="flex-1 px-8 py-4 bg-white text-deep-green font-semibold rounded-full border border-deep-green/20 hover:bg-deep-green hover:text-white transition-all duration-250 text-center"
                >
                  Request a Quote
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SPECS TABLE */}
      {product.fullSpecs && (
        <section className="py-16 lg:py-24 bg-surface">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <ScrollReveal>
              <h2 className="font-display text-3xl font-medium text-deep-green text-center mb-10">
                Full Specifications
              </h2>
            </ScrollReveal>
            <div className="bg-white rounded-xl border border-[rgba(26,26,46,0.10)] overflow-hidden">
              {Object.entries(product.fullSpecs).map(([key, value], i) => (
                <ScrollReveal key={key} delay={i * 0.05}>
                  <div
                    className={`flex justify-between items-center px-6 py-4 ${
                      i % 2 === 0 ? 'bg-white' : 'bg-surface'
                    } ${i !== 0 ? 'border-t border-[rgba(26,26,46,0.06)]' : ''}`}
                  >
                    <span className="text-sm font-semibold text-deep-green">{key}</span>
                    <span className="text-sm text-text-primary/80">{value}</span>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* WHY THIS BIKE */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <SectionHeader
              title="Why This Bike"
              align="center"
              className="mb-12"
            />
          </ScrollReveal>
          <motion.div
            variants={staggerContainerVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            {[
              { title: 'Built for Business', body: 'Reinforced cargo rack, heavy-duty frame, and low maintenance costs mean more deliveries per day.' },
              { title: 'Long-Range Freedom', body: '120km on a single charge covers a full delivery shift across Nairobi or Kampala.' },
              { title: 'East African Support', body: 'Local service centers, spare parts in stock, and a support team that understands your routes.' },
            ].map((item, i) => (
              <motion.div key={i} variants={staggerItemVariant} className="text-center">
                <h3 className="font-body text-lg font-semibold text-deep-green mb-2">{item.title}</h3>
                <p className="text-text-primary/70 text-sm leading-relaxed">{item.body}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* RELATED PRODUCTS */}
      <section className="py-16 lg:py-24 bg-light-green">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <SectionHeader
              title="You May Also Like"
              className="mb-10"
            />
          </ScrollReveal>
          <motion.div
            variants={staggerContainerVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.15 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-7"
          >
            {relatedProducts.map((rp) => (
              <motion.div key={rp.id} variants={staggerItemVariant}>
                <ProductCard
                  id={rp.id}
                  name={rp.name}
                  specs={rp.specs}
                  price={rp.price}
                  image={rp.image}
                  slug={rp.slug}
                />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
    </motion.div>
  );
}
