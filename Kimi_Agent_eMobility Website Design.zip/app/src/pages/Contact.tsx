import { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Clock, Mail, Phone, Instagram, Twitter, Linkedin, Youtube, Check } from 'lucide-react';
import ScrollReveal from '@/components/ScrollReveal';
import { pageTransitionVariant } from '@/animations/variants';

export default function Contact() {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <motion.div
      variants={pageTransitionVariant}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      {/* HERO */}
      <section className="pt-36 pb-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-display text-4xl lg:text-6xl font-medium text-deep-green">
            Get in Touch
          </h1>
          <p className="mt-4 text-text-primary/70 max-w-2xl mx-auto">
            Whether you're buying one bike or a hundred, we're here to help.
          </p>
        </div>
      </section>

      {/* CONTACT SPLIT LAYOUT */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_0.6fr] gap-12 lg:gap-16">
            {/* Form */}
            <ScrollReveal>
              {formSubmitted ? (
                <div className="bg-light-green rounded-xl p-12 text-center">
                  <div className="w-16 h-16 bg-electric-green rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check size={32} className="text-white" />
                  </div>
                  <h3 className="font-display text-2xl text-deep-green mb-2">Message Sent!</h3>
                  <p className="text-text-primary/70">Thank you for reaching out. We'll get back to you soon.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label className="block text-sm font-semibold text-deep-green mb-1.5">Name</label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-[rgba(26,26,46,0.12)] focus:border-electric-green focus:ring-2 focus:ring-electric-green/20 focus:outline-none transition-all"
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-deep-green mb-1.5">Email</label>
                      <input
                        type="email"
                        name="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-[rgba(26,26,46,0.12)] focus:border-electric-green focus:ring-2 focus:ring-electric-green/20 focus:outline-none transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-deep-green mb-1.5">Phone</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-[rgba(26,26,46,0.12)] focus:border-electric-green focus:ring-2 focus:ring-electric-green/20 focus:outline-none transition-all"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-deep-green mb-1.5">Subject</label>
                    <select
                      name="subject"
                      required
                      value={formData.subject}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-[rgba(26,26,46,0.12)] focus:border-electric-green focus:ring-2 focus:ring-electric-green/20 focus:outline-none transition-all bg-white"
                    >
                      <option value="">Select a subject</option>
                      <option value="General Enquiry">General Enquiry</option>
                      <option value="Sales">Sales</option>
                      <option value="Fleet Quote">Fleet Quote</option>
                      <option value="Support">Support</option>
                      <option value="Partnership">Partnership</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-deep-green mb-1.5">Message</label>
                    <textarea
                      name="message"
                      rows={5}
                      required
                      value={formData.message}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-[rgba(26,26,46,0.12)] focus:border-electric-green focus:ring-2 focus:ring-electric-green/20 focus:outline-none transition-all resize-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-8 py-4 bg-electric-green text-white font-semibold rounded-full hover:bg-deep-green hover:scale-[1.03] transition-all duration-250"
                  >
                    Send Message
                  </button>
                </form>
              )}
            </ScrollReveal>

            {/* Contact Details */}
            <ScrollReveal delay={0.2}>
              <div className="space-y-8">
                <div>
                  <h3 className="font-display text-xl text-deep-green mb-6">Our Offices</h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <MapPin size={18} className="text-electric-green mt-0.5 flex-shrink-0" />
                      <div className="text-sm text-text-primary/70">
                        <p className="font-medium text-deep-green">Move Different eMobility</p>
                        <p>Nairobi Garage, 4th Floor</p>
                        <p>Ngong Road, Nairobi, Kenya</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Clock size={18} className="text-electric-green mt-0.5 flex-shrink-0" />
                      <div className="text-sm text-text-primary/70">
                        <p className="font-medium text-deep-green">Office Hours</p>
                        <p>Mon–Fri: 8:00 AM – 6:00 PM (EAT)</p>
                        <p>Sat: 9:00 AM – 3:00 PM (EAT)</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Mail size={18} className="text-electric-green flex-shrink-0" />
                      <a href="mailto:hello@movedifferent.co.ke" className="text-sm text-text-primary/70 hover:text-electric-green transition-colors">
                        hello@movedifferent.co.ke
                      </a>
                    </div>
                    <div className="flex items-center gap-3">
                      <Phone size={18} className="text-electric-green flex-shrink-0" />
                      <a href="tel:+254712345678" className="text-sm text-text-primary/70 hover:text-electric-green transition-colors">
                        +254 712 345 678
                      </a>
                    </div>
                  </div>
                </div>

                {/* Social Icons */}
                <div>
                  <p className="text-sm font-semibold text-deep-green mb-4">Follow Us</p>
                  <div className="flex items-center gap-4">
                    <a href="#" className="text-deep-green hover:text-electric-green transition-colors">
                      <Instagram size={20} />
                    </a>
                    <a href="#" className="text-deep-green hover:text-electric-green transition-colors">
                      <Twitter size={20} />
                    </a>
                    <a href="#" className="text-deep-green hover:text-electric-green transition-colors">
                      <Linkedin size={20} />
                    </a>
                    <a href="#" className="text-deep-green hover:text-electric-green transition-colors">
                      <Youtube size={20} />
                    </a>
                  </div>
                </div>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* MAP */}
      <section className="relative">
        <ScrollReveal>
          <div className="w-full h-[400px] bg-surface relative overflow-hidden">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.8199!2d36.7857!3d-1.2921!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f10a8b5b5b5b5%3A0x5b5b5b5b5b5b5b5b!2sNgong%20Rd%2C%20Nairobi%2C%20Kenya!5e0!3m2!1sen!2s!4v1600000000000!5m2!1sen!2s"
              width="100%"
              height="100%"
              style={{ border: 0, filter: 'grayscale(20%) hue-rotate(100deg)' }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Move Different Office Location"
            />
            {/* Overlay Card */}
            <div className="absolute bottom-6 left-6 bg-white rounded-xl p-5 shadow-lg max-w-xs hidden sm:block">
              <h4 className="font-display text-lg text-deep-green mb-1">Visit Our Showroom</h4>
              <p className="text-sm text-text-primary/70">Nairobi Garage, Ngong Road</p>
              <a
                href="https://maps.google.com/?q=Ngong+Road+Nairobi+Kenya"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-electric-green font-medium mt-2 inline-block hover:underline"
              >
                Get Directions
              </a>
            </div>
          </div>
        </ScrollReveal>
      </section>
    </motion.div>
  );
}
