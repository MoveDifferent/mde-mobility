import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Zap, Leaf, MapPin } from 'lucide-react';
import { products } from '@/data/products';
import { testimonials } from '@/data/testimonials';
import ScrollReveal from '@/components/ScrollReveal';
import SectionHeader from '@/components/SectionHeader';
import ProductCard from '@/components/ProductCard';
import TestimonialCard from '@/components/TestimonialCard';
import { pageTransitionVariant, countUpVariant, staggerContainerVariant, staggerItemVariant } from '@/animations/variants';

const featuredProducts = products.filter(p => p.featured);

const stats = [
  { number: '5', label: 'Countries' },
  { number: '500+', label: 'Bikes Sold' },
  { number: '10+', label: 'Fleet Partners' },
  { number: '2026', label: 'Est. Since' },
];

const partners = ['Safaricom', 'Jumia', 'Glovo', 'Bolt', 'Sendy'];

export default function Home() {
  return (
    <motion.div
      variants={pageTransitionVariant}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      {/* HERO SECTION */}
      <section className="relative min-h-[100dvh] bg-white flex items-center justify-center overflow-hidden">
        {/* Side Images - Desktop Only */}
        <div className="hidden lg:block absolute left-[8vw] top-[22vh] w-[18vw] max-w-[280px] z-10">
          <ScrollReveal variant="scale-settle" delay={0.3}>
            <img
              src="/images/hero-left.jpg"
              alt="Rider on eBike"
              className="w-full shadow-[0_12px_40px_rgba(26,26,46,0.15)]"
            />
          </ScrollReveal>
        </div>
        <div className="hidden lg:block absolute right-[8vw] top-[18vh] w-[18vw] max-w-[280px] z-10">
          <ScrollReveal variant="scale-settle" delay={0.5}>
            <img
              src="/images/hero-right.jpg"
              alt="eBike detail"
              className="w-full shadow-[0_12px_40px_rgba(26,26,46,0.15)]"
            />
          </ScrollReveal>
        </div>

        {/* Decorative Lines */}
        <div className="hidden lg:block absolute left-[4vw] top-[15vh] w-px h-[200px] bg-deep-green/15" />
        <div className="hidden lg:block absolute right-[4vw] top-[12vh] w-px h-[160px] bg-deep-green/15" />

        {/* Main Content */}
        <div className="relative z-20 text-center px-4 max-w-3xl mx-auto pt-[18vh]">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xs font-semibold uppercase tracking-[0.15em] text-deep-green mb-6"
          >
            Move Different eMobility
          </motion.p>

          <div className="overflow-hidden mb-4">
            <motion.h1
              initial={{ y: '110%' }}
              animate={{ y: 0 }}
              transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
              className="font-display text-5xl sm:text-6xl lg:text-7xl xl:text-[90px] font-medium text-deep-green leading-[1.05] tracking-tight"
            >
              Move Different.
            </motion.h1>
          </div>
          <div className="overflow-hidden mb-8">
            <motion.h1
              initial={{ y: '110%' }}
              animate={{ y: 0 }}
              transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1], delay: 0.08 }}
              className="font-display text-5xl sm:text-6xl lg:text-7xl xl:text-[90px] font-medium text-deep-green leading-[1.05] tracking-tight"
            >
              Move Electric.
            </motion.h1>
          </div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-lg text-text-primary/80 max-w-xl mx-auto mb-10"
          >
            East Africa's premier eBike & eMobility brand — built for African roads, powered by green energy.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link
              to="/products"
              className="inline-flex items-center px-8 py-3.5 bg-electric-green text-white font-semibold rounded-full hover:bg-deep-green hover:scale-[1.03] hover:shadow-lg transition-all duration-250"
            >
              Shop eBikes
            </Link>
            <Link
              to="/fleet"
              className="inline-flex items-center px-8 py-3.5 bg-white text-deep-green font-semibold rounded-full border border-deep-green/20 hover:bg-deep-green hover:text-white transition-all duration-250"
            >
              Get a Fleet Quote
            </Link>
          </motion.div>
        </div>
      </section>

      {/* VALUE PROPOSITIONS */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={staggerContainerVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-10 lg:gap-16"
          >
            {[
              { icon: <Zap size={48} strokeWidth={1.5} />, title: 'Save on Fuel', body: 'Cut your running costs by up to 70%. Charge at home or at any standard outlet — no petrol station queues, no price hikes.' },
              { icon: <Leaf size={48} strokeWidth={1.5} />, title: 'Zero Emissions', body: 'Every kilometer ridden is a step towards cleaner cities. Reduce your carbon footprint without compromising mobility.' },
              { icon: <MapPin size={48} strokeWidth={1.5} />, title: 'Built for African Roads', body: 'Rugged frames, long-range batteries, and locally sourced parts. Designed for East African terrain and weather.' },
            ].map((item, i) => (
              <motion.div
                key={i}
                variants={staggerItemVariant}
                className="text-center lg:text-left group"
              >
                <div className="text-deep-green group-hover:text-electric-green transition-colors duration-250 inline-block mb-5">
                  {item.icon}
                </div>
                <h3 className="font-body text-xl font-semibold text-deep-green mb-3">{item.title}</h3>
                <p className="text-text-primary/70 leading-relaxed">{item.body}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* FEATURED PRODUCTS */}
      <section className="py-20 lg:py-28 bg-light-green">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <SectionHeader
              eyebrow="Our Range"
              title="Find Your Ride"
              className="mb-12"
            />
          </ScrollReveal>
          <motion.div
            variants={staggerContainerVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.15 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7"
          >
            {featuredProducts.map((product) => (
              <motion.div key={product.id} variants={staggerItemVariant}>
                <ProductCard
                  id={product.id}
                  name={product.name}
                  specs={product.specs}
                  price={product.price}
                  image={product.image}
                  slug={product.slug}
                />
              </motion.div>
            ))}
          </motion.div>
          <div className="text-center mt-12">
            <Link
              to="/products"
              className="inline-flex items-center px-8 py-3.5 bg-deep-green text-white font-semibold rounded-full hover:bg-electric-green hover:scale-[1.03] transition-all duration-250"
            >
              View All Products
            </Link>
          </div>
        </div>
      </section>

      {/* STATS BAR */}
      <section className="py-16 lg:py-20 bg-deep-green">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={staggerContainerVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center"
          >
            {stats.map((stat, i) => (
              <motion.div key={stat.label} variants={countUpVariant} custom={i}>
                <p className="font-display text-4xl lg:text-5xl xl:text-6xl text-white font-medium">
                  {stat.number}
                </p>
                <p className="text-white/70 text-xs font-semibold uppercase tracking-[0.12em] mt-2">
                  {stat.label}
                </p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <SectionHeader
              eyebrow="Rider Stories"
              title="What Our Community Says"
              align="center"
              className="mb-12"
            />
          </ScrollReveal>
          <motion.div
            variants={staggerContainerVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.15 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-7"
          >
            {testimonials.map((t) => (
              <motion.div key={t.id} variants={staggerItemVariant}>
                <TestimonialCard
                  quote={t.quote}
                  name={t.name}
                  role={t.role}
                  avatar={t.avatar}
                />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* PARTNERS LOGO STRIP */}
      <section className="py-12 lg:py-16 bg-surface">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <p className="text-center text-xs font-semibold uppercase tracking-[0.15em] text-deep-green/60 mb-8">
              Trusted By
            </p>
          </ScrollReveal>
          <div className="flex flex-wrap items-center justify-center gap-10 lg:gap-16">
            {partners.map((partner) => (
              <ScrollReveal key={partner} delay={0.1}>
                <span className="text-xl lg:text-2xl font-display font-semibold text-deep-green/40 hover:text-deep-green/70 transition-opacity duration-300 cursor-default">
                  {partner}
                </span>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* NEWSLETTER CTA */}
      <section className="py-20 lg:py-28 bg-electric-green">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollReveal>
            <h2 className="font-display text-3xl lg:text-5xl font-medium text-white mb-4">
              Join the eMobility Revolution
            </h2>
            <p className="text-white/90 mb-10">
              Get updates on new products, rider stories, and East African eMobility news.
            </p>
            <form
              onSubmit={(e) => e.preventDefault()}
              className="flex flex-col sm:flex-row items-center justify-center gap-3 max-w-lg mx-auto"
            >
              <input
                type="email"
                placeholder="Enter your email"
                className="w-full sm:flex-1 px-6 py-3.5 rounded-full bg-white text-text-primary placeholder:text-text-primary/50 focus:outline-none focus:ring-2 focus:ring-white/50"
              />
              <button
                type="submit"
                className="w-full sm:w-auto px-8 py-3.5 bg-deep-green text-white font-semibold rounded-full hover:bg-dark-base hover:scale-[1.03] transition-all duration-250"
              >
                Subscribe
              </button>
            </form>
          </ScrollReveal>
        </div>
      </section>
    </motion.div>
  );
}
