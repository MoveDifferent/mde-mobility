import { useState } from 'react';
import { motion } from 'framer-motion';
import { articles, categories } from '@/data/articles';
import ScrollReveal from '@/components/ScrollReveal';
import ArticleCard from '@/components/ArticleCard';
import { pageTransitionVariant, staggerContainerVariant, staggerItemVariant } from '@/animations/variants';

export default function Blog() {
  const [activeCategory, setActiveCategory] = useState('All');

  const featuredArticle = articles.find(a => a.featured);
  const regularArticles = articles.filter(a => !a.featured);

  const filteredArticles = activeCategory === 'All'
    ? regularArticles
    : regularArticles.filter(a => a.category === activeCategory);

  return (
    <motion.div
      variants={pageTransitionVariant}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      {/* HERO */}
      <section className="pt-36 pb-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-display text-4xl lg:text-6xl font-medium text-deep-green">
            News & Stories
          </h1>
          <p className="mt-4 text-text-primary/70 max-w-2xl mx-auto">
            Industry insights, product launches, and voices from the East African eMobility community.
          </p>
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="sticky top-[72px] z-40 bg-white border-b border-[rgba(26,26,46,0.08)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-6 overflow-x-auto py-3 scrollbar-hide">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`relative text-xs font-semibold uppercase tracking-[0.12em] whitespace-nowrap pb-2 transition-colors duration-250 ${
                  activeCategory === cat
                    ? 'text-deep-green'
                    : 'text-text-primary/50 hover:text-deep-green'
                }`}
              >
                {cat}
                {activeCategory === cat && (
                  <motion.span
                    layoutId="blogFilter"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-electric-green rounded-full"
                  />
                )}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ARTICLE GRID */}
      <section className="py-12 lg:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Featured Article */}
          {featuredArticle && activeCategory === 'All' && (
            <ScrollReveal>
              <ArticleCard
                id={featuredArticle.id}
                title={featuredArticle.title}
                excerpt={featuredArticle.excerpt}
                category={featuredArticle.category}
                date={featuredArticle.date}
                image={featuredArticle.image}
                featured
              />
            </ScrollReveal>
          )}

          {/* Regular Articles */}
          <motion.div
            variants={staggerContainerVariant}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7 mt-8"
          >
            {filteredArticles.map((article) => (
              <motion.div key={article.id} variants={staggerItemVariant} layout>
                <ArticleCard
                  id={article.id}
                  title={article.title}
                  excerpt={article.excerpt}
                  category={article.category}
                  date={article.date}
                  image={article.image}
                />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
    </motion.div>
  );
}
