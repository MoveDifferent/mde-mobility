import { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Wrench, CreditCard, Check } from 'lucide-react';
import ScrollReveal from '@/components/ScrollReveal';
import SectionHeader from '@/components/SectionHeader';
import { pageTransitionVariant, staggerContainerVariant, staggerItemVariant } from '@/animations/variants';

const fleetOfferings = [
  { icon: <Users size={48} strokeWidth={1.5} />, title: 'Bulk Pricing', body: 'Volume discounts starting at 5 units. The more you buy, the more you save.' },
  { icon: <Wrench size={48} strokeWidth={1.5} />, title: 'After-Sales Support', body: 'Dedicated fleet managers, on-site maintenance training, and priority spare parts allocation.' },
  { icon: <CreditCard size={48} strokeWidth={1.5} />, title: 'Flexible Financing', body: 'Lease-to-own, asset financing, and quarterly payment plans tailored to your cash flow.' },
];

const useCases = [
  { image: '/images/fleet-delivery.jpg', title: 'Delivery Companies', desc: 'Last-mile logistics, food delivery, and courier services.' },
  { image: '/images/fleet-ride-hailing.jpg', title: 'Ride-Hailing', desc: 'Eco-friendly boda boda and taxi fleets for urban mobility.' },
  { image: '/images/fleet-ngo.jpg', title: 'NGOs & Corporates', desc: 'Sustainable transport for field teams and staff commuting.' },
  { image: '/images/fleet-government.jpg', title: 'Government', desc: 'Municipal fleets, park patrol, and public service vehicles.' },
];

export default function Fleet() {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    companyName: '',
    bikeCount: '',
    useCase: '',
    contactName: '',
    email: '',
    phone: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <motion.div
      variants={pageTransitionVariant}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      {/* HERO */}
      <section className="pt-36 pb-20 lg:pb-28 bg-deep-green">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="overflow-hidden mb-4">
            <motion.h1
              initial={{ y: '110%' }}
              animate={{ y: 0 }}
              transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
              className="font-display text-4xl sm:text-5xl lg:text-7xl font-medium text-white leading-[1.05]"
            >
              Power Your Fleet.
            </motion.h1>
          </div>
          <div className="overflow-hidden mb-8">
            <motion.h1
              initial={{ y: '110%' }}
              animate={{ y: 0 }}
              transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1], delay: 0.08 }}
              className="font-display text-4xl sm:text-5xl lg:text-7xl font-medium text-white leading-[1.05]"
            >
              Cut Your Costs.
            </motion.h1>
          </div>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-lg text-white/80 max-w-2xl mx-auto"
          >
            Bulk pricing, after-sales support, and flexible financing for delivery companies, ride-hailing platforms, NGOs, and government fleets.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="mt-8"
          >
            <a
              href="#enquiry"
              className="inline-flex items-center px-8 py-3.5 bg-white text-deep-green font-semibold rounded-full hover:bg-light-green hover:scale-[1.03] transition-all duration-250"
            >
              Get a Fleet Quote
            </a>
          </motion.div>
        </div>
      </section>

      {/* FLEET OFFERING */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={staggerContainerVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-10 lg:gap-16"
          >
            {fleetOfferings.map((item, i) => (
              <motion.div key={i} variants={staggerItemVariant} className="text-center lg:text-left group">
                <div className="text-deep-green group-hover:text-electric-green transition-colors duration-250 inline-block mb-5">
                  {item.icon}
                </div>
                <h3 className="font-body text-xl font-semibold text-deep-green mb-3">{item.title}</h3>
                <p className="text-text-primary/70 leading-relaxed">{item.body}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* USE CASES */}
      <section className="py-20 lg:py-28 bg-surface">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <SectionHeader
              title="Solutions for Every Industry"
              align="center"
              className="mb-12"
            />
          </ScrollReveal>
          <motion.div
            variants={staggerContainerVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.15 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-7"
          >
            {useCases.map((uc, i) => (
              <motion.div key={i} variants={staggerItemVariant} className="group">
                <div className="aspect-[16/9] overflow-hidden rounded-lg">
                  <img
                    src={uc.image}
                    alt={uc.title}
                    className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
                    loading="lazy"
                  />
                </div>
                <h3 className="font-body text-lg font-semibold text-deep-green mt-4">{uc.title}</h3>
                <p className="text-text-primary/70 text-sm mt-1">{uc.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* FLEET ENQUIRY FORM */}
      <section id="enquiry" className="py-20 lg:py-28 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <SectionHeader
              title="Get Your Fleet Quote"
              align="center"
              subtitle="Tell us about your fleet needs and we'll get back to you within 24 hours."
              className="mb-12"
            />
          </ScrollReveal>

          <div className="grid grid-cols-1 lg:grid-cols-[1fr_0.8fr] gap-12">
            {/* Form */}
            <ScrollReveal>
              {formSubmitted ? (
                <div className="bg-light-green rounded-xl p-10 text-center">
                  <div className="w-16 h-16 bg-electric-green rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check size={32} className="text-white" />
                  </div>
                  <h3 className="font-display text-2xl text-deep-green mb-2">Thank You!</h3>
                  <p className="text-text-primary/70">We'll be in touch within 24 hours with a tailored proposal.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label className="block text-sm font-semibold text-deep-green mb-1.5">Company Name</label>
                    <input
                      type="text"
                      name="companyName"
                      required
                      value={formData.companyName}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-[rgba(26,26,46,0.12)] focus:border-electric-green focus:ring-2 focus:ring-electric-green/20 focus:outline-none transition-all"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-deep-green mb-1.5">Number of Bikes</label>
                      <select
                        name="bikeCount"
                        required
                        value={formData.bikeCount}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-[rgba(26,26,46,0.12)] focus:border-electric-green focus:ring-2 focus:ring-electric-green/20 focus:outline-none transition-all bg-white"
                      >
                        <option value="">Select</option>
                        <option value="5-10">5–10</option>
                        <option value="11-25">11–25</option>
                        <option value="26-50">26–50</option>
                        <option value="50+">50+</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-deep-green mb-1.5">Use Case</label>
                      <select
                        name="useCase"
                        required
                        value={formData.useCase}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-[rgba(26,26,46,0.12)] focus:border-electric-green focus:ring-2 focus:ring-electric-green/20 focus:outline-none transition-all bg-white"
                      >
                        <option value="">Select</option>
                        <option value="Delivery">Delivery</option>
                        <option value="Ride-Hailing">Ride-Hailing</option>
                        <option value="NGO">NGO</option>
                        <option value="Government">Government</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-deep-green mb-1.5">Contact Name</label>
                    <input
                      type="text"
                      name="contactName"
                      required
                      value={formData.contactName}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-[rgba(26,26,46,0.12)] focus:border-electric-green focus:ring-2 focus:ring-electric-green/20 focus:outline-none transition-all"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-deep-green mb-1.5">Email</label>
                      <input
                        type="email"
                        name="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-[rgba(26,26,46,0.12)] focus:border-electric-green focus:ring-2 focus:ring-electric-green/20 focus:outline-none transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-deep-green mb-1.5">Phone</label>
                      <input
                        type="tel"
                        name="phone"
                        required
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-[rgba(26,26,46,0.12)] focus:border-electric-green focus:ring-2 focus:ring-electric-green/20 focus:outline-none transition-all"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-deep-green mb-1.5">Message (Optional)</label>
                    <textarea
                      name="message"
                      rows={4}
                      value={formData.message}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-[rgba(26,26,46,0.12)] focus:border-electric-green focus:ring-2 focus:ring-electric-green/20 focus:outline-none transition-all resize-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-8 py-4 bg-electric-green text-white font-semibold rounded-full hover:bg-deep-green hover:scale-[1.03] transition-all duration-250"
                  >
                    Send Enquiry
                  </button>
                </form>
              )}
            </ScrollReveal>

            {/* Info Column */}
            <ScrollReveal delay={0.2}>
              <div className="bg-surface rounded-xl p-8">
                <h3 className="font-display text-xl text-deep-green mb-4">
                  Talk to Our Fleet Team
                </h3>
                <p className="text-text-primary/70 text-sm mb-6">
                  We'll get back to you within 24 hours with a tailored proposal.
                </p>
                <ul className="space-y-3">
                  {[
                    'Custom pricing for your fleet size',
                    'Free pilot program for qualifying fleets',
                    'On-site demo available in Nairobi, Kampala, and Dar es Salaam',
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-text-primary/80">
                      <Check size={16} className="text-electric-green mt-0.5 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* TESTIMONIAL */}
      <section className="py-16 lg:py-20 bg-light-green">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollReveal>
            <p className="font-display text-xl lg:text-2xl italic text-deep-green leading-relaxed">
              &ldquo;The fleet program cut our delivery costs by half. The support team is always available.&rdquo;
            </p>
            <p className="mt-6 text-text-primary/70 text-sm">
              — Grace Auma, Operations Director, Jumia Uganda
            </p>
          </ScrollReveal>
        </div>
      </section>

      {/* DOWNLOAD BROCHURE */}
      <section className="py-16 bg-electric-green">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollReveal>
            <p className="text-white text-lg font-semibold mb-6">
              Download our Fleet Solutions Brochure (PDF)
            </p>
            <button className="inline-flex items-center px-8 py-3.5 bg-white text-electric-green font-semibold rounded-full hover:bg-light-green hover:scale-[1.03] transition-all duration-250">
              Download Brochure
            </button>
          </ScrollReveal>
        </div>
      </section>
    </motion.div>
  );
}
