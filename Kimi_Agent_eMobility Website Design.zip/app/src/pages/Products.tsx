import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { products } from '@/data/products';
import ScrollReveal from '@/components/ScrollReveal';
import ProductCard from '@/components/ProductCard';
import { pageTransitionVariant, staggerContainerVariant, staggerItemVariant } from '@/animations/variants';

const filterTabs = ['All', 'Commuter', 'Cargo', 'Scooter', 'Accessory'];

export default function Products() {
  const [activeFilter, setActiveFilter] = useState('All');

  const filteredProducts = activeFilter === 'All'
    ? products
    : products.filter(p => p.category.toLowerCase() === activeFilter.toLowerCase());

  return (
    <motion.div
      variants={pageTransitionVariant}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      {/* PAGE HERO */}
      <section className="pt-36 pb-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-display text-4xl lg:text-6xl font-medium text-deep-green">
            Our Products
          </h1>
          <p className="mt-4 text-text-primary/70 max-w-2xl mx-auto">
            Commuter bikes, cargo workhorses, scooters, and accessories — all built for East Africa.
          </p>
        </div>
      </section>

      {/* FILTER BAR */}
      <section className="sticky top-[72px] z-40 bg-white border-b border-[rgba(26,26,46,0.08)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-6 overflow-x-auto py-4 scrollbar-hide">
            {filterTabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveFilter(tab)}
                className={`relative text-xs font-semibold uppercase tracking-[0.12em] whitespace-nowrap pb-2 transition-colors duration-250 ${
                  activeFilter === tab
                    ? 'text-deep-green'
                    : 'text-text-primary/50 hover:text-deep-green'
                }`}
              >
                {tab}
                {activeFilter === tab && (
                  <motion.span
                    layoutId="productFilter"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-electric-green rounded-full"
                  />
                )}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* PRODUCT GRID */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={staggerContainerVariant}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-7"
          >
            {filteredProducts.map((product) => (
              <motion.div key={product.id} variants={staggerItemVariant} layout>
                <ProductCard
                  id={product.id}
                  name={product.name}
                  specs={product.specs}
                  price={product.price}
                  image={product.image}
                  slug={product.slug}
                />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* FEATURED PRODUCT BANNER */}
      <section className="py-20 lg:py-28 bg-light-green">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <ScrollReveal variant="scale-settle">
              <img
                src="/images/delivery-pro.jpg"
                alt="Delivery Pro"
                className="w-full aspect-[4/3] object-cover"
              />
            </ScrollReveal>
            <ScrollReveal>
              <p className="text-xs font-semibold uppercase tracking-[0.15em] text-deep-green mb-3">
                Featured
              </p>
              <h2 className="font-display text-3xl lg:text-4xl font-medium text-deep-green mb-4">
                Delivery Pro — Built for Business
              </h2>
              <p className="text-text-primary/70 mb-8 leading-relaxed">
                The ultimate last-mile delivery machine. 120km range, heavy-duty cargo rack, and fleet-ready telemetry. Designed to handle the demands of daily delivery operations across East Africa.
              </p>
              <Link
                to="/fleet"
                className="inline-flex items-center px-8 py-3.5 bg-electric-green text-white font-semibold rounded-full hover:bg-deep-green hover:scale-[1.03] transition-all duration-250"
              >
                Request a Fleet Quote
              </Link>
            </ScrollReveal>
          </div>
        </div>
      </section>
    </motion.div>
  );
}
