import { Link } from 'react-router-dom';
import { Instagram, Twitter, Linkedin, Youtube } from 'lucide-react';

const quickLinks = [
  { name: 'Home', path: '/' },
  { name: 'Products', path: '/products' },
  { name: 'Fleet Solutions', path: '/fleet' },
  { name: 'About', path: '/about' },
  { name: 'Blog', path: '/blog' },
  { name: 'Contact', path: '/contact' },
];

const productCategories = [
  { name: 'Commuter eBikes', path: '/products' },
  { name: 'Cargo eBikes', path: '/products' },
  { name: 'Scooters', path: '/products' },
  { name: 'Accessories', path: '/products' },
  { name: 'Fleet Solutions', path: '/fleet' },
];

export default function Footer() {
  return (
    <footer className="bg-dark-base text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">
          {/* Brand Column */}
          <div className="space-y-6">
            <Link to="/" className="inline-block">
              <span className="font-display text-2xl font-semibold text-white">
                Move Different
              </span>
            </Link>
            <p className="text-light-green/80 text-sm leading-relaxed">
              East Africa's Premier eMobility Brand
            </p>
            <div className="flex items-center space-x-4">
              <a href="#" className="text-white/60 hover:text-electric-green transition-colors duration-250">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-white/60 hover:text-electric-green transition-colors duration-250">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-white/60 hover:text-electric-green transition-colors duration-250">
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-white/60 hover:text-electric-green transition-colors duration-250">
                <Youtube size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-[0.12em] text-white/40 mb-6">
              Quick Links
            </h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.path}
                    className="text-white/70 hover:text-electric-green transition-colors duration-250 text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Product Categories */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-[0.12em] text-white/40 mb-6">
              Product Categories
            </h4>
            <ul className="space-y-3">
              {productCategories.map((cat) => (
                <li key={cat.name}>
                  <Link
                    to={cat.path}
                    className="text-white/70 hover:text-electric-green transition-colors duration-250 text-sm"
                  >
                    {cat.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-[0.12em] text-white/40 mb-6">
              Contact
            </h4>
            <div className="space-y-3 text-sm text-white/70">
              <p>Nairobi, Kenya</p>
              <p>hello@movedifferent.co.ke</p>
              <p>+254 712 345 678</p>
            </div>
            <a
              href="https://wa.me/254712345678?text=Hi! I'd like to learn more about Move Different eMobility."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center mt-6 px-5 py-2.5 bg-electric-green text-white text-xs font-semibold uppercase tracking-[0.12em] rounded-full hover:bg-deep-green transition-colors duration-250"
            >
              WhatsApp Us
            </a>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-white/10">
          <p className="text-white/40 text-sm text-center">
            &copy; 2026 Move Different eMobility. A Move Different Group Company.
          </p>
        </div>
      </div>
    </footer>
  );
}
