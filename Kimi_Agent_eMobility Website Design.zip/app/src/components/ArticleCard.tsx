import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

interface ArticleCardProps {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  date: string;
  image: string;
  featured?: boolean;
}

export default function ArticleCard({
  title,
  excerpt,
  category,
  date,
  image,
  featured = false,
}: ArticleCardProps) {
  if (featured) {
    return (
      <motion.div
        whileHover={{ y: -4 }}
        transition={{ duration: 0.25 }}
        className="group col-span-full mb-8"
      >
        <Link to={`/blog`} className="block">
          <div className="aspect-[21/9] overflow-hidden rounded-lg">
            <img
              src={image}
              alt={title}
              className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
              loading="lazy"
            />
          </div>
          <div className="mt-5">
            <span className="inline-block px-3 py-1 bg-light-green text-deep-green text-xs font-semibold uppercase tracking-wider rounded-full">
              {category}
            </span>
            <h3 className="font-display text-2xl lg:text-3xl font-medium text-deep-green mt-3 group-hover:text-electric-green transition-colors">
              {title}
            </h3>
            <p className="text-text-primary/70 mt-2 line-clamp-2 max-w-3xl">{excerpt}</p>
            <p className="text-text-primary/50 text-sm mt-3">{date}</p>
          </div>
        </Link>
      </motion.div>
    );
  }

  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.25 }}
      className="group"
    >
      <Link to={`/blog`} className="block">
        <div className="aspect-[16/9] overflow-hidden rounded-lg">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
            loading="lazy"
          />
        </div>
        <div className="mt-4">
          <span className="inline-block px-3 py-1 bg-light-green text-deep-green text-xs font-semibold uppercase tracking-wider rounded-full">
            {category}
          </span>
          <h3 className="font-body text-lg font-semibold text-deep-green mt-3 group-hover:text-electric-green transition-colors line-clamp-2">
            {title}
          </h3>
          <p className="text-text-primary/70 text-sm mt-2 line-clamp-3">{excerpt}</p>
          <div className="flex items-center justify-between mt-3">
            <p className="text-text-primary/50 text-xs">{date}</p>
            <span className="text-sm text-deep-green font-medium relative">
              Read More
              <span className="absolute bottom-0 left-0 w-0 h-px bg-deep-green group-hover:w-full transition-all duration-300" />
            </span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
