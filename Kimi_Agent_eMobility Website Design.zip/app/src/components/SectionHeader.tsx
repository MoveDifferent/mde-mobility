interface SectionHeaderProps {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  align?: 'left' | 'center';
  light?: boolean;
  className?: string;
}

export default function SectionHeader({
  eyebrow,
  title,
  subtitle,
  align = 'left',
  light = false,
  className = '',
}: SectionHeaderProps) {
  return (
    <div className={`${align === 'center' ? 'text-center' : 'text-left'} max-w-2xl ${align === 'center' ? 'mx-auto' : ''} ${className}`}>
      {eyebrow && (
        <p className={`text-xs font-semibold uppercase tracking-[0.15em] mb-3 ${light ? 'text-white/70' : 'text-deep-green'}`}>
          {eyebrow}
        </p>
      )}
      <h2 className={`font-display text-3xl lg:text-4xl font-medium leading-tight ${light ? 'text-white' : 'text-deep-green'}`}>
        {title}
      </h2>
      {subtitle && (
        <p className={`mt-4 text-base leading-relaxed ${light ? 'text-white/80' : 'text-text-primary/80'}`}>
          {subtitle}
        </p>
      )}
    </div>
  );
}
