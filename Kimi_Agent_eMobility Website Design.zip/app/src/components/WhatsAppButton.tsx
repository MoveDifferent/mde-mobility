import { MessageCircle } from 'lucide-react';
import { motion } from 'framer-motion';

interface WhatsAppButtonProps {
  phoneNumber?: string;
  message?: string;
}

export default function WhatsAppButton({
  phoneNumber = '254712345678',
  message = "Hi! I'd like to learn more about Move Different eMobility.",
}: WhatsAppButtonProps) {
  const waUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

  return (
    <motion.a
      href={waUrl}
      target="_blank"
      rel="noopener noreferrer"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1], delay: 1.2 }}
      className="fixed bottom-6 right-6 z-40 inline-flex items-center gap-2 px-5 py-3 bg-electric-green text-white rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-250"
    >
      <MessageCircle size={20} />
      <span className="hidden sm:inline text-sm font-semibold">Chat on WhatsApp</span>
    </motion.a>
  );
}
