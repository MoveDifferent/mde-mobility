import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

interface ProductCardProps {
  id: string;
  name: string;
  specs: string;
  price: string;
  image: string;
  slug: string;
}

export default function ProductCard({ name, specs, price, image, slug }: ProductCardProps) {
  return (
    <motion.div
      whileHover={{ y: -6 }}
      transition={{ duration: 0.25, ease: [0.25, 0.1, 0.25, 1] }}
      className="group bg-white rounded-xl overflow-hidden border border-[rgba(26,26,46,0.10)] shadow-[0_8px_30px_rgba(26,26,46,0.08)] hover:shadow-[0_12px_40px_rgba(26,26,46,0.12)] transition-shadow duration-250"
    >
      <Link to={`/products/${slug}`} className="block">
        <div className="aspect-[4/3] overflow-hidden">
          <img
            src={image}
            alt={name}
            className="w-full h-full object-cover group-hover:scale-[1.04] transition-transform duration-500 ease-[cubic-bezier(0.25,0.1,0.25,1)]"
            loading="lazy"
          />
        </div>
        <div className="p-5">
          <h3 className="font-body text-lg font-semibold text-deep-green">{name}</h3>
          <p className="text-sm text-text-primary/70 mt-1">{specs}</p>
          <div className="flex items-center justify-between mt-4">
            <span className="text-electric-green font-semibold">{price}</span>
            <span className="text-sm text-deep-green font-medium relative group/link">
              Learn More
              <span className="absolute bottom-0 left-0 w-0 h-px bg-deep-green group-hover/link:w-full transition-all duration-300" />
            </span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
