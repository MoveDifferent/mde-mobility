import { Star } from 'lucide-react';

interface TestimonialCardProps {
  quote: string;
  name: string;
  role: string;
  avatar?: string;
}

export default function TestimonialCard({ quote, name, role, avatar }: TestimonialCardProps) {
  return (
    <div className="bg-white rounded-xl p-6 lg:p-8 border border-[rgba(26,26,46,0.08)] shadow-[0_8px_30px_rgba(26,26,46,0.06)] hover:shadow-[0_12px_40px_rgba(26,26,46,0.10)] hover:-translate-y-1 transition-all duration-250">
      <div className="flex items-center gap-1 mb-4">
        {[...Array(5)].map((_, i) => (
          <Star key={i} size={16} className="fill-electric-green text-electric-green" />
        ))}
      </div>
      <p className="font-display text-lg lg:text-xl italic text-deep-green leading-relaxed">
        &ldquo;{quote}&rdquo;
      </p>
      <div className="flex items-center gap-3 mt-6">
        {avatar && (
          <img
            src={avatar}
            alt={name}
            className="w-12 h-12 rounded-full object-cover"
            loading="lazy"
          />
        )}
        <div>
          <p className="font-semibold text-deep-green text-sm">{name}</p>
          <p className="text-text-primary/60 text-sm">{role}</p>
        </div>
      </div>
    </div>
  );
}
