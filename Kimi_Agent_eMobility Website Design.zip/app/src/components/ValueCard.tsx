import { Zap, Leaf, MapPin, Users, Wrench, CreditCard, Heart } from 'lucide-react';
import type { ReactNode } from 'react';

const iconMap: Record<string, ReactNode> = {
  Zap: <Zap size={48} strokeWidth={1.5} />,
  Leaf: <Leaf size={48} strokeWidth={1.5} />,
  MapPin: <MapPin size={48} strokeWidth={1.5} />,
  Users: <Users size={48} strokeWidth={1.5} />,
  Wrench: <Wrench size={48} strokeWidth={1.5} />,
  CreditCard: <CreditCard size={48} strokeWidth={1.5} />,
  Heart: <Heart size={48} strokeWidth={1.5} />,
};

interface ValueCardProps {
  icon: string;
  title: string;
  description: string;
}

export default function ValueCard({ icon, title, description }: ValueCardProps) {
  return (
    <div className="group text-center lg:text-left">
      <div className="text-deep-green group-hover:text-electric-green transition-colors duration-250 inline-block mb-4">
        {iconMap[icon] || <Zap size={48} strokeWidth={1.5} />}
      </div>
      <h3 className="font-body text-lg font-semibold text-deep-green mb-2">{title}</h3>
      <p className="text-text-primary/70 text-sm leading-relaxed">{description}</p>
    </div>
  );
}
